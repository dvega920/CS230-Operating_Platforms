package com.gamingroom;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */

// Re-factored Team class to inherit from base class Entity.
public class Team extends Entity {
	long id;
	String name;
	
	private static List<Team> teams = new ArrayList<Team>();

	
	/*
	 * Constructor with an identifier and name
	 */
	public Team(long id, String name) {
		this.id = id;
		this.name = name;
	}

//	/**
//	 * @return the id
//	 */
//	public long getId() {
//		return id;
//	}
//
//	/**
//	 * @return the name
//	 */
//	public String getName() {
//		return name;
//	}

	
	public Team addTeam(String name) {
		Team temp = null;
		
		for (Team current : teams) {
			if(current.name.equalsIgnoreCase(name)){
				return current;
			}
			
		}
		
		//If Team isn't found call the GamerService to get the nextTeamId
		
		GameService tempService = GameService.getInstance();
		
		temp = new Team(tempService.getNextTeamId(), name);
		
		teams.add(temp);
		
		return temp;
	}
	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + "]";
	}
}
