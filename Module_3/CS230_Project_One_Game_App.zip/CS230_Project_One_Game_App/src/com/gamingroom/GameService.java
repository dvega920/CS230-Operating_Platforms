package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {
	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;
	
	/*
	 * Holds the next player identifier
	 */
	
	private static long nextPlayerId = 1;
	
	/*
	 * Holds the next team identifier
	 */
	
	private static long nextTeamId = 1;

	// FIXME: Add missing pieces to turn this class a singleton 
	
	// The singleton pattern ensures that only one instance is running at a time. 
	// This is accomplished by setting the creator method GameService() as a private method to the GameService class.
	// This ensures that an instance will be created only when the constructor is invoked and chained with the instance creator method. 
	// When an instance of GameService is created the logic checks to see if the value is null. If null, then an instance is created. If not, returns the instance.
		
	private static GameService service = null;
	
	//Default constructor
	private GameService(){
	}

	public static GameService getInstance() {
		
		if(service == null) {
			
			service = new GameService();
			
//			System.out.println("New Game Service created.");
			
		} else {
//			System.out.println("Game Service already instantiated.");
		}
		
		return service;
	}
	
	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		// a local game instance
		Game game = null;

		// FIXME: Use iterator to look for existing game with same name
		// if found, simply return the existing instance
		
		// The below method will invoke the getGame method and pass in a string. The code will proceed to check
		// the value returned by getGame(name). If the value is not null, then game will be set to the string passed in to getGame(name). 
		// If value is null, the code will store the increment of nextGameId and string name and assign it to game.
		// the game will then be added to the array games. 
		// The method returns the new/existing game.
		
		if (getGame(name) != null) {
			
			game = getGame(name);
		}
		else {
			// if not found, make a new game instance and add to list of games
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		// FIXME: Use iterator to look for existing game with same id
		// if found, simply assign that instance to the local variable
		
		// The below iterates through the games array and searches for the id. 
		// if the current game id equals the id passed in, game is set to the current game.
		for (Game currGame : games) {
			if(currGame.getId() == id) {
				game = currGame;
				break;
			}
		}
		
		return game;
	}
	
	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		// FIXME: Use iterator to look for existing game with same name
		// if found, simply assign that instance to the local variable
		
		// The below iterates through the games array and checks for a match to the name passed in. 
		// If a match is found the game is set to the current game.
		for (Game currGame : games) {
			if(currGame.getName().equalsIgnoreCase(name)) {
				game = currGame;
				break;
			}
		}
		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
	
	//Add methods to return the nextPlayerId and nextTeamId
	
	public long getNextPlayerId() {
		return nextPlayerId++;
	}
	
	public long getNextTeamId() {
		return nextTeamId++;
	}
}
