package com.gamingroom;

public class Entity {
	
	// protected modifier is a reserved keyword that allows the data member to be accessed only within the package
	// while private modifier is a reserved keyword that allows the data member to be accessed only within its own class. 
	protected long id;
	protected String name;
	
	protected Entity() {} // constructor method also set to protected so they can be accessed by subclasses within the package.
	
	public Entity(long id, String name) { // overloaded method that is passed in id and name as params.
		this.id = id;
		this.name = name;
	}
	
	public long getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}

}
