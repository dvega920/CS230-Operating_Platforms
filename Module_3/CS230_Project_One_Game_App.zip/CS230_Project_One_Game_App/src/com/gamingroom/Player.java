package com.gamingroom;

import java.util.ArrayList;
import java.util.List;



/**
 * A simple class to hold information about a player
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a player is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */

// Re-factored Player class to inherit from base class Entity.
public class Player extends Entity {
	long id;
	String name;
	
	private static List<Player> players = new ArrayList<Player>();
	
	/*
	 * Constructor with an identifier and name
	 */
	public Player(long id, String name) {
		this.id = id;
		this.name = name;
	}

//	/**
//	 * @return the id
//	 */
//	public long getId() {
//		return id;
//	}
//
//	/**
//	 * @return the name
//	 */
//	public String getName() {
//		return name;
//	}
	
	// create method to return player with specified name 
	// iterate through players list to retrieve the current player.
	// if current player doesn't exist, call GameService to retrieve the nextPlayerId and assign new player to temp container.
	// add temp (new player) to the players list.
	// return temp (new player).

	public Player addPlayer(String name) {
		
		Player temp = null;
		
		for(Player current : players) {
			if(current.name.equalsIgnoreCase(name)) {
				return current;
			}
		}
		
		GameService tempService = GameService.getInstance();
		
		temp = new Player(tempService.getNextPlayerId(), name);
		
		players.add(temp);
		
		return temp;
		
	}
	@Override
	public String toString() {
		return "Player [id=" + id + ", name=" + name + "]";
	}
}
